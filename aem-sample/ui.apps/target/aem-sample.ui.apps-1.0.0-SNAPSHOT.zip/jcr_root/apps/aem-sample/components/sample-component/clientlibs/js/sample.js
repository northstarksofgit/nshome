//window.onload = function(){
//    title = resource.properties["hardCode"];
//    console.log(title);
//};


function test(){
	alert("test!");
}